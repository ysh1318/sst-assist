# 🎓 SST Assist — AI Learning Companion

A clean, safe, Socratic AI learning companion built specifically for Scaler Academy students.

---

## 🛡️ 100% Academic Integrity Safe (Zero Semester Risk)
- **Read-Only Accessibility**: This extension only reads the problem title and text currently displayed on your screen so the AI has context.
- **No Cheat Scripts**: It has **zero automated solving, zero DOM button clicking, zero code injection, and zero auto-submission**.
- **Pedagogical Socratic Model**: Following the Harvard CS50 AI Duck & Khanmigo benchmarks, it guides you step-by-step using mental models, logic blueprints, and diagnostic questions so you genuinely learn.

---

## 🚀 How to Install & Use (1 Minute Setup)

### 1. Load the Extension in your Browser (Chrome, Brave, Edge)
1. Open your browser and navigate to `chrome://extensions` (or `brave://extensions` / `edge://extensions`).
2. Toggle on **Developer mode** (top-right corner).
3. Click **Load unpacked** (top-left button).
4. Select this folder (`sst-assist`).
5. Pin the extension to your toolbar.

### 2. Add your Free Groq API Key
1. Get a 100% free API key from [Groq Console](https://console.groq.com/keys) (takes 30 seconds to sign in with Google or GitHub).
2. Click the extension icon on any Scaler Academy problem page to open the side panel.
3. Click the **⚙ Settings** icon at the top right of the side panel.
4. Paste your Groq API key and click **Save Settings**.

---

## 💡 How to Study with the Tutor

- **`1 Intuition`**: Click this whenever you don't understand what a problem is asking. The tutor will provide an everyday analogy or mental model without spoiling anything.
- **`2 Blueprint`**: Get a high-level pseudocode or step-by-step algorithmic outline.
- **`3 Bug Check`**: Review edge cases, off-by-one errors, and common traps.
- **Quick Chips**: Click `Concept`, `Trace Example`, `Edge Cases`, or `Complexity` for instant targeted explanations.
- **Interactive Chat**: Type your doubts, paste your code error messages, or ask the tutor to explain why a test case failed.
- **Emergency Bailout (`🔓 Full Solution`)**: If you've struggled for hours and need to see the complete reference implementation with line-by-line explanations and Time/Space complexity, click this button.
