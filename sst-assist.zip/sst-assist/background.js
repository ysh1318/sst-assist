// background.js - Service worker for SST Assist with Alt+A Native Action Toggle

let sidePanelPort = null;
let pendingSelection = "";
let lastToggleTime = 0;

// Force openPanelOnActionClick to false at top level so action.onClicked and shortcuts always fire
if (chrome.sidePanel && chrome.sidePanel.setPanelBehavior) {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: false }).catch(() => {});
}

chrome.runtime.onInstalled.addListener(() => {
  if (chrome.sidePanel && chrome.sidePanel.setPanelBehavior) {
    chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: false }).catch(() => {});
  }
});

// Track active side panel connection
chrome.runtime.onConnect.addListener((port) => {
  if (port.name === "sst-assist-channel") {
    sidePanelPort = port;

    // Send summon event + any captured selection on open
    if (pendingSelection) {
      port.postMessage({ action: "SUMMON_FOCUS", selection: pendingSelection });
      pendingSelection = "";
    } else {
      port.postMessage({ action: "SUMMON_FOCUS" });
    }

    port.onDisconnect.addListener(() => {
      sidePanelPort = null;
    });

    port.onMessage.addListener(async (msg) => {
      if (msg.action === "REQUEST_CLOSE_PANEL") {
        closeSidePanel(msg.windowId);
      }
    });
  }
});

// Programmatic close fallback
async function closeSidePanel(windowId) {
  if (chrome.sidePanel && typeof chrome.sidePanel.close === "function") {
    try {
      if (windowId) {
        await chrome.sidePanel.close({ windowId });
      } else {
        const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
        if (tab?.windowId) await chrome.sidePanel.close({ windowId: tab.windowId });
      }
    } catch (_) {}
  }
}

// Master Toggle Function (Synchronous to preserve Chromium user gesture token!)
function toggleSidePanel(tab) {
  const now = Date.now();
  if (now - lastToggleTime < 300) return; // Prevent double-trigger debounce
  lastToggleTime = now;

  // 1. If panel is currently open -> smoothly close it
  if (sidePanelPort) {
    try {
      sidePanelPort.postMessage({ action: "TOGGLE_CLOSE" });
    } catch (_) {
      sidePanelPort = null;
    }
    return;
  }

  // 2. Open panel IMMEDIATELY on this synchronous execution tick
  // MUST NOT await any promise before this line, otherwise Chrome kills the user gesture!
  const winId = tab?.windowId;
  if (winId) {
    chrome.sidePanel.open({ windowId: winId }).catch((err) => {
      console.warn("[SST Assist] Could not open with windowId:", err);
      if (tab?.id) {
        chrome.sidePanel.open({ tabId: tab.id }).catch(() => {});
      }
    });
  } else if (tab?.id) {
    chrome.sidePanel.open({ tabId: tab.id }).catch(() => {});
  } else {
    chrome.tabs.query({ active: true, lastFocusedWindow: true }).then(([activeTab]) => {
      if (activeTab?.windowId) {
        chrome.sidePanel.open({ windowId: activeTab.windowId }).catch(() => {});
      }
    });
  }

  // 3. Selection fetch happens out-of-band and never delays open()
  if (tab?.id) {
    chrome.tabs.sendMessage(tab.id, { action: "GET_SELECTION" }).then((res) => {
      if (res?.selection) {
        if (sidePanelPort) {
          sidePanelPort.postMessage({ action: "SUMMON_FOCUS", selection: res.selection });
        } else {
          pendingSelection = res.selection;
        }
      }
    }).catch(() => {});
  }
}

// Action icon click & _execute_action shortcut (Alt+A) triggers toggle synchronously
chrome.action.onClicked.addListener((tab) => {
  toggleSidePanel(tab);
});

// Command listener for fallback or direct triggers
chrome.commands.onCommand.addListener((command, tab) => {
  toggleSidePanel(tab);
});

// Enable side panel on Scaler tabs
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (tab.url && tab.url.includes("scaler.com")) {
    try {
      chrome.sidePanel.setOptions({
        tabId,
        path: "sidepanel/sidepanel.html",
        enabled: true
      });
    } catch (_) {}
  }
});
