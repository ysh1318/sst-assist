// content/content.js - Academic Safe Read-Only DOM Reader for SST Assist

(function () {
  console.log("[SST Assist] Active on Scaler Academy (Read-Only Mode).");

  // Respond only to read requests
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === "GET_QUESTION") {
      const data = window.SST_Extractor ? window.SST_Extractor.extractCurrentQuestion() : null;
      sendResponse({ success: !!data, data });
      return false;
    }
    if (message.action === "GET_SELECTION") {
      const sel = window.getSelection() ? window.getSelection().toString().trim() : "";
      sendResponse({ selection: sel });
      return false;
    }
  });

  // Watch for question navigation changes
  let lastKnownUrl = window.location.href;
  let lastQuestionTitle = "";

  const observer = new MutationObserver(() => {
    if (window.location.href !== lastKnownUrl) {
      lastKnownUrl = window.location.href;
      notifyQuestionChange();
      return;
    }

    const titleEl = document.querySelector(".cr-p-heading__text");
    const currentTitle = titleEl ? titleEl.innerText.trim() : "";
    if (currentTitle && currentTitle !== lastQuestionTitle) {
      lastQuestionTitle = currentTitle;
      notifyQuestionChange();
    }
  });

  observer.observe(document.body, { childList: true, subtree: true });

  function notifyQuestionChange() {
    try {
      chrome.runtime.sendMessage({
        action: "PAGE_QUESTION_CHANGED",
        url: window.location.href,
        title: lastQuestionTitle
      }).catch(() => {});
    } catch (_) {}
  }
})();
