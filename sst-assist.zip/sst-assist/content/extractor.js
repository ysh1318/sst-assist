// content/extractor.js - DOM Scraper for Scaler Assignments and Live Classroom Quizzes

(function () {
  // Helper to extract question details and detect question layout (handles both Assignments & Live Session Quizzes)
  function extractCurrentQuestion() {
    const isLiveSessionPage = window.location.href.includes("/session") || 
                              !!document.querySelector(".meeting-app, .meeting, .m-quiz, .m-problem-choices, .mcq-hq, .mcq-preview, .problem-preview");

    // ========================================================
    // 1. LIVE CLASSROOM SESSION QUIZZES / POLLS (Drona Quizzes)
    // ========================================================
    if (isLiveSessionPage) {
      const sessionName = document.querySelector(".m-header__name")?.innerText.trim() || 
                          document.querySelector("[data-cy='meeting-header-name']")?.innerText.trim() ||
                          document.querySelector(".m-header")?.innerText.trim() ||
                          document.title.replace(/- Class\s*\|\s*Scaler Academy/i, "").replace(/\|\s*Lecture/i, "").trim() ||
                          "Live Lecture";

      const liveQuizStatementEl = document.querySelector(".m-problem-description__markdown") ||
                                  document.querySelector(".m-problem-description") ||
                                  document.querySelector(".m-quiz__problem .md-renderer") ||
                                  document.querySelector(".m-quiz__problem") ||
                                  document.querySelector(".problem-preview__description .md-renderer") ||
                                  document.querySelector(".problem-preview__markdown") ||
                                  document.querySelector(".problem-preview__description") ||
                                  document.querySelector(".mcq-preview__problem .md-renderer") ||
                                  document.querySelector(".mcq-preview .problem-preview__description");
      let statement = liveQuizStatementEl ? liveQuizStatementEl.innerText.trim() : "";

      // Scrape live choices (Drona choices: .m-problem-choices .choice, a.tappable.choice)
      const rawLiveChoices = Array.from(document.querySelectorAll(
        ".m-problem-choices__list .choice, .m-problem-choices .choice, .m-quiz__choices .choice, .m-quiz .choice, .problem-preview__choices a.choice, .problem-preview__choices .choice, .mcq-preview a.choice, a.tappable.choice, .choice"
      ));

      // Filter to choices within the meeting/quiz context
      const liveChoiceElements = rawLiveChoices.filter(el => {
        return !!el.closest(".m-quiz, .m-problem-choices, .problem-preview, .mcq-preview, .mcq-hq, .meeting-app, .meeting, .react-root");
      });

      const options = [];
      liveChoiceElements.forEach((el, index) => {
        const nameEl = el.querySelector(".choice__name");
        let name = nameEl ? nameEl.innerText.trim() : "";
        if (!name) name = String.fromCharCode(65 + index);

        const textEl = el.querySelector(".choice__text") || el;
        let rawText = textEl.innerText.trim();
        if (name && rawText.startsWith(name)) {
          rawText = rawText.slice(name.length).trim();
        }

        const fullText = name ? `[${name}] ${rawText}` : rawText;
        const isSelected = el.classList.contains("choice--selected") || 
                           el.classList.contains("selected") || 
                           el.classList.contains("active") || 
                           el.classList.contains("choice--active") ||
                           el.classList.contains("choice--locked") ||
                           el.getAttribute("aria-checked") === "true";

        options.push({
          index: index,
          name: name,
          text: fullText,
          rawText: rawText,
          isSelected: isSelected,
          inputType: "radio"
        });
      });

      // Filter out placeholder unlaunched preview quizzes
      const isPlaceholder = (statement === "" || statement.includes("Problem statement will be displayed here")) &&
                            (options.length === 0 || options.every(o => o.rawText === "Option 1" || o.rawText === "Option 2"));

      let questionType = "LIVE_SESSION_WAITING";
      let title = `${sessionName} (Live Class)`;

      if (!isPlaceholder && options.length > 0) {
        questionType = "LIVE_QUIZ_MCQ";
        title = `${sessionName} (Live Quiz)`;
      } else if (!isPlaceholder && statement.length > 0) {
        questionType = "LIVE_QUIZ_MCQ";
        title = `${sessionName} (Live Quiz)`;
      } else {
        statement = "🎙️ Live Class in progress. Waiting for instructor to launch the live quiz / poll...";
      }

      const isAttempted = !!document.querySelector(".choice--locked, .choice--selected, .m-quiz__small-text.success") ||
                          options.some(o => o.isSelected);

      const problemContainer = document.querySelector(".m-quiz") ||
                               document.querySelector(".m-problem-choices") ||
                               document.querySelector(".mcq-preview") || 
                               document.querySelector(".problem-preview") || 
                               document.querySelector(".mcq-hq") ||
                               document.querySelector(".meeting-app") ||
                               document.body;
      const domHtml = problemContainer ? problemContainer.outerHTML : "";

      return {
        url: window.location.href,
        title,
        questionType,
        programmingLanguage: null,
        starterCode: null,
        statement,
        options,
        isSolved: isAttempted,
        isUnsolved: (questionType === "LIVE_QUIZ_MCQ" && !isAttempted),
        currentQNumber: "LIVE",
        hasOptions: options.length > 0,
        domHtml: domHtml,
        isLiveSession: true
      };
    }

    // ========================================================
    // 2. ASSIGNMENT / HOMEWORK PROBLEMS (Single, Multi, Coding, Subjective)
    // ========================================================
    const firstSpan = document.querySelector(".cr-p-heading__text > span:first-child");
    const titleEl = document.querySelector(".cr-p-heading__text");
    let title = "Unknown Question";
    if (firstSpan) {
      title = firstSpan.innerText.replace(/\s+/g, " ").trim();
    } else if (titleEl) {
      title = titleEl.innerText.replace(/\s+/g, " ").trim();
    }

    const statementEl = document.querySelector(".cr-p-statement") || 
                        document.querySelector(".html-content__container");
    let statement = "";
    if (statementEl) {
      statement = statementEl.innerText.trim();
    }

    // MCQ Options (Radio or Checkbox)
    const optionContainers = document.querySelectorAll(".cr-multiple-choice-container__choices .cr-multiple-choice");
    const options = [];

    optionContainers.forEach((container, index) => {
      const labelEl = container.querySelector(".cr-multiple-choice__label") || container;
      const text = labelEl.innerText.trim();
      const inputEl = container.querySelector('input[type="radio"], input[type="checkbox"]');
      const isSelected = inputEl ? inputEl.checked : false;

      options.push({
        index: index,
        text: text,
        isSelected: isSelected,
        inputType: inputEl ? inputEl.type : "radio"
      });
    });

    // Detect Question Type
    let questionType = "MCQ_SINGLE";
    const checkboxes = document.querySelectorAll('.cr-multiple-choice-container__choices input[type="checkbox"]');
    const radios = document.querySelectorAll('.cr-multiple-choice-container__choices input[type="radio"]');
    const monacoEditor = document.querySelector(".monaco-editor, .ace_editor, .react-monaco-editor-container");
    const codeArea = document.querySelector(".cr-code-editor, .me-cr-code-editor, .code-editor-container");
    const subjectiveArea = document.querySelector(".cr-subjective-editor, .cr-subjective-editor__textarea, textarea.cr-subjective-editor__textarea");
    const textInputs = document.querySelectorAll(".cr-p-statement input[type='text'], .cr-fill-in-the-blank, textarea:not(.inputarea)");

    let programmingLanguage = null;
    let starterCode = null;

    if (monacoEditor || codeArea) {
      questionType = "CODING";

      // Extract programming language from toolbar dropdown
      const langDropdown = document.querySelector(".cr-editor-toolbar-dropdown__single-value, .cr-editor-toolbar-dropdown");
      if (langDropdown) {
        programmingLanguage = langDropdown.innerText.trim();
      }

      // Detect Frontend Judge tabs (e.g. index.html, style.css, script.js)
      const activeTab = document.querySelector(".pg-tabs-container__tabs.pg-tabs-container__active span, .pg-tabs-container__active span");
      const monacoMode = document.querySelector("[data-mode-id]")?.getAttribute("data-mode-id");
      const isFrontendJudge = !!document.querySelector(".cr-frontend-judge, .pg-playground-wrapper, .pg-editor-container");

      if (isFrontendJudge || activeTab || (monacoMode && ["html", "css", "javascript", "typescript"].includes(monacoMode))) {
        if (activeTab?.innerText) {
          const tabName = activeTab.innerText.trim();
          if (tabName.endsWith(".html")) programmingLanguage = "HTML";
          else if (tabName.endsWith(".css")) programmingLanguage = "CSS";
          else if (tabName.endsWith(".js")) programmingLanguage = "JavaScript";
          else programmingLanguage = tabName;
        } else if (monacoMode) {
          programmingLanguage = monacoMode.toUpperCase();
        } else {
          programmingLanguage = "HTML";
        }
      }

      // Extract starter code from Monaco view-lines
      const viewLines = document.querySelectorAll(".monaco-editor .view-lines .view-line");
      if (viewLines.length > 0) {
        starterCode = Array.from(viewLines).map(line => line.textContent || "").join("\n");
      }
    } else if (checkboxes.length > 0) {
      questionType = "MCQ_MULTI";
    } else if (radios.length > 0) {
      questionType = "MCQ_SINGLE";
    } else if (subjectiveArea || textInputs.length > 0) {
      questionType = "SUBJECTIVE";
    } else if (options.length > 0) {
      questionType = "MCQ_SINGLE";
    } else {
      questionType = "UNKNOWN";
    }

    const solvedBadge = document.querySelector(".status-tag-2--success");
    const isSolved = !!solvedBadge && solvedBadge.innerText.toLowerCase().includes("solved");
    const unsolvedBadge = document.querySelector(".status-tag-2--attention");
    const isUnsolved = isSolved ? false : (!solvedBadge || (!!unsolvedBadge && unsolvedBadge.innerText.toLowerCase().includes("unsolved")));

    const activeDockItem = document.querySelector(".cr-p-navigation-dock-item--active");
    const currentQNumber = activeDockItem ? activeDockItem.innerText.trim() : "";

    // Problem DOM HTML for telemetry
    const problemContainer = document.querySelector(".me-cr-problem") || 
                             document.querySelector(".cr-problems-container__body") || 
                             document.body;
    const domHtml = problemContainer ? problemContainer.outerHTML : "";

    return {
      url: window.location.href,
      title,
      questionType,
      programmingLanguage,
      starterCode,
      statement,
      options,
      isSolved,
      isUnsolved,
      currentQNumber,
      hasOptions: options.length > 0,
      domHtml: domHtml,
      isLiveSession: false
    };
  }

  // Capture full DOM debug snapshot for telemetry and local debugging
  function getDebugScene() {
    const submitBtn = document.querySelector(".cr-multiple-choice-container__submit") ||
                      document.querySelector(".cr-subjective-editor__submit") ||
                      document.querySelector(".cr-judge-action--submit") ||
                      document.querySelector(".pg-test-wrapper__submit");
    const optionContainers = document.querySelectorAll(".cr-multiple-choice-container__choices .cr-multiple-choice");
    const activeDock = document.querySelector(".cr-p-navigation-dock-item--active");
    const dockItems = Array.from(document.querySelectorAll(".cr-p-navigation-dock__list a.me-cr-p-nav-dock-item"));
    const modals = Array.from(document.querySelectorAll(".sr-modal, .dialog")).map(m => ({
      classes: m.className,
      text: m.innerText.trim().slice(0, 150),
      display: window.getComputedStyle(m).display
    }));

    const problemContainer = document.querySelector(".me-cr-problem") || 
                             document.querySelector(".cr-problems-container__body") ||
                             document.querySelector(".mcq-preview") ||
                             document.querySelector(".problem-preview");

    return {
      timestamp: new Date().toISOString(),
      url: window.location.href,
      pageTitle: document.title,
      activeQuestionDock: activeDock ? activeDock.innerText.trim() : null,
      totalDockQuestions: dockItems.length,
      questionHeader: document.querySelector(".cr-p-heading__text")?.innerText.trim() || null,
      statementSnippet: document.querySelector(".cr-p-statement")?.innerText.slice(0, 200) || null,
      optionsCount: optionContainers.length,
      optionsState: Array.from(optionContainers).map((c, i) => ({
        index: i,
        text: c.innerText.trim().slice(0, 80),
        checked: c.querySelector('input[type="radio"], input[type="checkbox"]')?.checked ?? null,
        type: c.querySelector('input[type="radio"], input[type="checkbox"]')?.type ?? "unknown",
        classes: c.className
      })),
      submitButton: submitBtn ? {
        exists: true,
        disabled: submitBtn.disabled,
        classes: submitBtn.className,
        text: submitBtn.innerText.trim()
      } : { exists: false },
      visibleToasts: Array.from(document.querySelectorAll("#ct-container .ct-toast")).map(t => t.innerText.trim()),
      modals: modals,
      domHtml: problemContainer ? problemContainer.outerHTML : ""
    };
  }

  // Export to global scope for content scripts
  window.SST_Extractor = {
    extractCurrentQuestion,
    getDebugScene
  };
})();
