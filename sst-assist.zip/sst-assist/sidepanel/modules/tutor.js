// sidepanel/modules/tutor.js - Socratic AI Tutor Studio, Chat Stream & Zen Markdown Formatter

(function () {
  function escapeHtml(str) {
    if (!str) return "";
    return String(str)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  // Enhanced Zen Markdown Formatter for Tutor Chat
  function formatMarkdown(text) {
    if (!text) return "";
    
    // Process text safely
    let html = escapeHtml(text);

    // 1. Fenced Code Blocks with Language Header & Copy Action
    html = html.replace(/```([a-zA-Z0-9_\-\+]*)\n([\s\S]*?)```/g, (match, lang, code) => {
      const language = lang ? lang.trim().toLowerCase() : "code";
      const cleanCode = code.trim();
      return `<div class="code-block-wrap">
        <div class="code-block-header">
          <span class="code-lang-tag">${language}</span>
          <button class="code-copy-btn" title="Copy snippet to clipboard">Copy</button>
        </div>
        <pre><code class="language-${language}">${cleanCode}</code></pre>
      </div>`;
    });

    // 2. Tables (e.g. Dry Run / Execution Trace)
    html = html.replace(/(?:^|\n)\|(.+)\|\n\|(?:\s*[-:]+[-| :]*)\|\n((?:\|.+\|\n?)+)/g, (match, headerLine, bodyLines) => {
      const headers = headerLine.split("|").map(h => h.trim()).filter(Boolean);
      const thHtml = headers.map(h => `<th>${h}</th>`).join("");

      const rows = bodyLines.trim().split("\n");
      const trHtml = rows.map(r => {
        const cells = r.split("|").map(c => c.trim()).filter(Boolean);
        return `<tr>${cells.map(c => `<td>${c}</td>`).join("")}</tr>`;
      }).join("");

      return `<div class="table-wrap"><table class="tutor-table"><thead><tr>${thHtml}</tr></thead><tbody>${trHtml}</tbody></table></div>`;
    });

    // 3. Blockquotes / Callout Tips
    html = html.replace(/(?:^|\n)&gt;\s*\[!(?:TIP|NOTE|HINT)\]\s*([\s\S]*?)(?=(?:\n\n|\n[^\s&]|$))/gi, (match, content) => {
      return `<blockquote class="tutor-callout tip"><span class="callout-icon"><svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/></svg></span><div class="callout-text">${content.trim()}</div></blockquote>`;
    });
    html = html.replace(/(?:^|\n)&gt;\s*\[!(?:WARNING|TRAP|CAUTION)\]\s*([\s\S]*?)(?=(?:\n\n|\n[^\s&]|$))/gi, (match, content) => {
      return `<blockquote class="tutor-callout warn"><span class="callout-icon"><svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg></span><div class="callout-text">${content.trim()}</div></blockquote>`;
    });
    html = html.replace(/(?:^|\n)&gt;\s*([^\n]+)/g, (match, line) => {
      return `<blockquote class="tutor-callout"><div class="callout-text">${line.trim()}</div></blockquote>`;
    });

    // 4. Headings
    html = html.replace(/^###\s+(.+)$/gm, '<h4 class="tutor-heading h4">$1</h4>');
    html = html.replace(/^##\s+(.+)$/gm, '<h3 class="tutor-heading h3">$1</h3>');

    // 5. Math Expressions (Inline $formula$ or `O(...)`)
    html = html.replace(/\$([^\$\n]+)\$/g, '<span class="tutor-math">$1</span>');

    // 6. Inline code `code`
    html = html.replace(/`([^`\n]+)`/g, '<code class="inline-code">$1</code>');

    // 7. Bold & Italic
    html = html.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
    html = html.replace(/\*([^*]+)\*/g, "<em>$1</em>");

    // 8. Unordered Lists
    html = html.replace(/^(?:[-*]\s+)(.+)$/gm, '<li class="tutor-list-item">$1</li>');
    html = html.replace(/((?:<li class="tutor-list-item">[\s\S]*?<\/li>\s*)+)/g, '<ul class="tutor-list">$1</ul>');

    // 9. Clean line breaks
    html = html.replace(/\n\n+/g, "<br><br>");
    html = html.replace(/\n/g, "<br>");

    // Cleanup wrapping around blocks
    html = html.replace(/<br>\s*(<div class="code-block-wrap">)/g, "$1");
    html = html.replace(/(<\/div>)\s*<br>/g, "$1");
    html = html.replace(/<br>\s*(<div class="table-wrap">)/g, "$1");
    html = html.replace(/(<\/table><\/div>)\s*<br>/g, "$1");
    html = html.replace(/<br>\s*(<blockquote)/g, "$1");
    html = html.replace(/(<\/blockquote>)\s*<br>/g, "$1");
    html = html.replace(/<br>\s*(<ul)/g, "$1");
    html = html.replace(/(<\/ul>)\s*<br>/g, "$1");

    return html;
  }

  // Append message card to Assistant Chat Stream
  function appendChatMessage(chatStreamEl, role, content) {
    if (!chatStreamEl) return;
    
    // Hide empty state hero when conversation starts
    const heroEl = chatStreamEl.querySelector("#geminiHero");
    if (heroEl) heroEl.style.display = "none";

    const isTutor = role === "assistant";
    const msgEl = document.createElement("div");
    msgEl.className = `chat-message ${isTutor ? "tutor-message" : "user-message"}`;

    const avatar = document.createElement("div");
    avatar.className = `chat-avatar ${isTutor ? "tutor-avatar" : "user-avatar"}`;
    avatar.innerHTML = isTutor ? `
      <svg class="avatar-svg sst-avatar" viewBox="0 0 32 32" fill="none">
        <rect width="32" height="32" rx="8" fill="#0d111c"/>
        <path d="M20 9.5H13.5C11.5 9.5 10 11 10 13C10 15 11.5 16 13.5 16.5H18.5C20.5 17 22 18 22 20C22 22 20.5 23.5 18.5 23.5H11" stroke="#38bdf8" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M23.5 5.5C23.5 7.5 25.2 9 27.5 9C25.2 9 23.5 10.5 23.5 12.5C23.5 10.5 21.8 9 19.5 9C21.8 9 23.5 7.5 23.5 5.5Z" fill="#818cf8"/>
      </svg>
    ` : `
      <svg class="avatar-svg user-avatar" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"></path>
        <circle cx="12" cy="7" r="4"></circle>
      </svg>
    `;

    const contentWrap = document.createElement("div");
    contentWrap.className = "chat-content";

    const sender = document.createElement("div");
    sender.className = "chat-sender";
    sender.innerText = isTutor ? "SST Assist" : "You";

    const bubble = document.createElement("div");
    bubble.className = "chat-bubble";
    bubble.innerHTML = isTutor ? formatMarkdown(content) : escapeHtml(content);

    contentWrap.appendChild(sender);
    contentWrap.appendChild(bubble);

    msgEl.appendChild(avatar);
    msgEl.appendChild(contentWrap);

    chatStreamEl.appendChild(msgEl);
    chatStreamEl.scrollTop = chatStreamEl.scrollHeight;

    // Attach 1-click copy handlers to code blocks in this bubble
    bubble.querySelectorAll(".code-copy-btn").forEach(btn => {
      btn.addEventListener("click", () => {
        const codeEl = btn.closest(".code-block-wrap")?.querySelector("pre code");
        if (codeEl) {
          navigator.clipboard.writeText(codeEl.innerText).then(() => {
            const originalText = btn.innerText;
            btn.innerText = "✓ Copied";
            btn.classList.add("copied");
            setTimeout(() => {
              btn.innerText = originalText;
              btn.classList.remove("copied");
            }, 1800);
          });
        }
      });
    });
  }

  // Show animated typing indicator
  function showTypingIndicator(chatStreamEl) {
    removeTypingIndicator();
    if (!chatStreamEl) return;
    const ind = document.createElement("div");
    ind.id = "assistantTypingIndicator";
    ind.className = "chat-message tutor-message typing-indicator-wrap";
    ind.innerHTML = `
      <div class="chat-avatar tutor-avatar">
        <svg class="avatar-svg sst-avatar" viewBox="0 0 32 32" fill="none">
          <rect width="32" height="32" rx="8" fill="#0d111c"/>
          <path d="M20 9.5H13.5C11.5 9.5 10 11 10 13C10 15 11.5 16 13.5 16.5H18.5C20.5 17 22 18 22 20C22 22 20.5 23.5 18.5 23.5H11" stroke="#38bdf8" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M23.5 5.5C23.5 7.5 25.2 9 27.5 9C25.2 9 23.5 10.5 23.5 12.5C23.5 10.5 21.8 9 19.5 9C21.8 9 23.5 7.5 23.5 5.5Z" fill="#818cf8"/>
        </svg>
      </div>
      <div class="chat-content">
        <div class="chat-sender">SST Assist</div>
        <div class="chat-bubble typing-bubble">
          <div class="typing-dots">
            <span class="typing-dot"></span>
            <span class="typing-dot"></span>
            <span class="typing-dot"></span>
          </div>
          <span class="typing-label">Contemplating guidance...</span>
        </div>
      </div>
    `;
    chatStreamEl.appendChild(ind);
    chatStreamEl.scrollTop = chatStreamEl.scrollHeight;
  }

  // Remove typing indicator
  function removeTypingIndicator() {
    const ind = document.getElementById("assistantTypingIndicator");
    if (ind) ind.remove();
  }

  // Send interactive question to Socratic Tutor
  async function sendAssistantMessage(options = {}) {
    const {
      userText,
      questionData,
      chatHistory = [],
      chatStreamEl,
      apiKey,
      model = "openai/gpt-oss-20b",
      isSolutionBailout = false,
      onLog = null
    } = options;

    if (!userText || !userText.trim()) return;
    const trimmed = userText.trim();

    if (!apiKey) {
      if (onLog) onLog("Please configure your Groq API Key to chat with the Tutor.", "warn");
      return;
    }

    appendChatMessage(chatStreamEl, "user", trimmed);
    chatHistory.push({ role: "user", content: trimmed });
    showTypingIndicator(chatStreamEl);

    const isCoding = questionData?.questionType === "CODING";
    const optionsText = (questionData?.options || []).map((o, i) => `[${i + 1}] (${o.inputType || "option"}) ${o.text}`).join("\n");

    let systemInstruction = "";

    if (isSolutionBailout) {
      // Emergency Bailout / Solution Walkthrough
      systemInstruction = `You are "SST Assist" — a world-class, empathetic computer science professor assisting an undergrad student on Scaler Academy.
The student has spent significant effort and explicitly requested a full, pedagogical solution breakdown.

YOUR DIRECTIVES:
1. Provide the complete, clean, optimal solution code for this problem.
2. Follow up with a clear, step-by-step breakdown explaining:
   - The key invariant or mathematical theorem.
   - Why each major section of the code exists.
   - Time Complexity (O(...)) and Space Complexity (O(...)).
3. Highlight the subtle bug or edge cases (e.g. integer overflow, off-by-one, 0-indexing) that students typically miss.
4. Keep the tone encouraging, warm, and clear. Format code cleanly with language tags.`;
    } else {
      // Standard Socratic Pedagogical Partner
      systemInstruction = `You are "SST Assist" — an elite, inspiring computer science mentor assisting an undergrad student on Scaler Academy.

PEDAGOGICAL CORE DIRECTIVES (HARVARD CS50 & KHANMIGO BENCHMARK):
1. THE SOCRATIC NO-ANSWER CONSTRAINT:
   - ABSOLUTELY NEVER dump the direct answer, option letter (e.g., "Choose B"), or full solution code.
   - Your primary mission is to foster "Productive Struggle" so the student discovers the insight themselves.

2. PROGRESSIVE 3-TIER SCAFFOLDING:
   - Tier 1 (Intuition): When asked for a hint, provide a mental model, analogy, or intuitive visual concept (e.g., modular clock, two runners on a track).
   - Tier 2 (Logic Blueprint): If the student is still stuck, outline the algorithmic steps or pseudocode without revealing the implementation.
   - Tier 3 (Line-Level Bug Spotting): If the student has code, pinpoint the specific line or operator causing issues (e.g., "Look closely at line 12: does the loop terminate before or after the array ends?").

3. TURN ECONOMICS & COGNITIVE LOAD:
   - Keep answers concise: 2 to 3 short, punchy paragraphs maximum. Never write overwhelming essays.
   - ALWAYS conclude your response with exactly ONE targeted, thought-provoking question or small challenge (e.g., "What value does \`i\` have when the loop finishes?").

4. VISUAL & MATHEMATICAL CLARITY:
   - If tracing an algorithm, use a compact markdown table for dry-run execution steps.
   - Format math using clean LaTeX notation ($A^{-1} \\pmod M$) and bold key variables.
   - Tone: Deeply supportive, intellectually stimulating, calm, and conversational.`;
    }

    const contextMessage = `CURRENT PROBLEM ON STUDENT'S SCREEN:
Title: ${questionData?.title || "Unknown Problem"}
Type: ${questionData?.questionType || "ASSIGNMENT"}
Programming Language: ${questionData?.programmingLanguage || "Java/C++/Python/HTML"}

Problem Statement:
${questionData?.statement || "No statement available."}

${isCoding ? `Student / Starter Code Provided:\n\`\`\`${(questionData?.programmingLanguage || "").toLowerCase()}\n${questionData?.starterCode || "No starter code"}\n\`\`\`` : ""}
${optionsText ? `Available Options:\n${optionsText}` : ""}`;

    const systemPromptWithContext = `${systemInstruction}\n\n=== CONTEXT OF CURRENT PROBLEM ON STUDENT'S SCREEN ===\n${contextMessage}`;

    const messagesPayload = [
      { role: "system", content: systemPromptWithContext }
    ];

    if (chatHistory.length > 1) {
      // Prior conversational turns (excluding the latest user turn pushed at line 197)
      const recentHistory = chatHistory.slice(-7, -1);
      recentHistory.forEach(h => {
        messagesPayload.push({ role: h.role, content: h.content });
      });
    }
    messagesPayload.push({ role: "user", content: trimmed });

    try {
      const res = await fetch("https://api.groq.com/openai/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${apiKey}`
        },
        body: JSON.stringify({
          model: model,
          messages: messagesPayload,
          temperature: isSolutionBailout ? 0.3 : 0.5,
          max_tokens: 1800
        })
      });

      removeTypingIndicator();

      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error?.message || `HTTP ${res.status}`);
      }

      const data = await res.json();
      const reply = data.choices?.[0]?.message?.content || "Sorry, I could not generate an explanation.";
      appendChatMessage(chatStreamEl, "assistant", reply);
      chatHistory.push({ role: "assistant", content: reply });
    } catch (err) {
      removeTypingIndicator();
      appendChatMessage(chatStreamEl, "assistant", `⚠️ Tutor Error: ${err.message}`);
      if (onLog) onLog(`Tutor error: ${err.message}`, "error");
    }
  }

  // Export module to window
  window.SST_Tutor = {
    formatMarkdown,
    appendChatMessage,
    showTypingIndicator,
    removeTypingIndicator,
    sendAssistantMessage
  };
})();
