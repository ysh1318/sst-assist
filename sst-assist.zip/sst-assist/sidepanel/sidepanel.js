// sidepanel/sidepanel.js - Main Controller for SST Socratic AI Tutor

(function () {
  let currentQuestion = null;
  let chatHistory = [];

  // DOM Elements - Header & Settings
  const btnSettingsToggle = document.getElementById("btnSettingsToggle");
  const btnCloseSettings = document.getElementById("btnCloseSettings");
  const settingsSection = document.getElementById("settingsSection");
  const apiKeyInput = document.getElementById("apiKeyInput");
  const modelSelect = document.getElementById("modelSelect");
  const btnFetchModels = document.getElementById("btnFetchModels");
  const btnSaveSettings = document.getElementById("btnSaveSettings");
  const settingsFeedback = document.getElementById("settingsFeedback");

  // DOM Elements - Problem Ribbon
  const ribbonQ = document.getElementById("ribbonQ");
  const ribbonTitle = document.getElementById("ribbonTitle");
  const ribbonLang = document.getElementById("ribbonLang");
  const btnSyncProblem = document.getElementById("btnSyncProblem");

  // DOM Elements - Hint Ladder & Suggestion Cards
  const ladderPills = document.querySelectorAll(".scaffold-pill");

  // DOM Elements - Chat & Input
  const chatStream = document.getElementById("chatStream");
  const chatInput = document.getElementById("chatInput");
  const btnSend = document.getElementById("btnSend");
  const btnBailout = document.getElementById("btnBailout");
  const btnClear = document.getElementById("btnClear");

  // ----------------------------------------------------
  // Smooth Close & Port Communication with Background
  // ----------------------------------------------------
  let isClosing = false;
  async function triggerSmoothClose() {
    if (isClosing) return;
    isClosing = true;
    document.body.classList.add("is-closing");
    setTimeout(async () => {
      try {
        const win = await chrome.windows.getCurrent();
        if (chrome.sidePanel && typeof chrome.sidePanel.close === "function") {
          await chrome.sidePanel.close({ windowId: win.id });
        } else {
          window.close();
        }
      } catch (_) {
        window.close();
      }
    }, 170);
  }

  function handleSummonFocus(selection = "") {
    if (!chatInput) return;
    const capsule = chatInput.closest(".input-capsule");
    if (capsule) {
      capsule.classList.remove("summon-glow");
      void capsule.offsetWidth;
      capsule.classList.add("summon-glow");
      setTimeout(() => capsule.classList.remove("summon-glow"), 900);
    }

    if (selection && selection.trim()) {
      chatInput.value = `"${selection.trim()}"\n\nExplain this: `;
      chatInput.style.height = "auto";
      chatInput.style.height = Math.min(chatInput.scrollHeight, 120) + "px";
    }

    chatInput.focus();
    const len = chatInput.value.length;
    chatInput.setSelectionRange(len, len);
  }

  // Connect to background service worker for Alt+A Toggle
  try {
    const assistPort = chrome.runtime.connect({ name: "sst-assist-channel" });
    assistPort.onMessage.addListener((msg) => {
      if (msg.action === "TOGGLE_CLOSE") {
        triggerSmoothClose();
      } else if (msg.action === "SUMMON_FOCUS") {
        handleSummonFocus(msg.selection);
      }
    });
  } catch (_) {}

  // ----------------------------------------------------
  // Configuration & Settings
  // ----------------------------------------------------
  async function loadConfig() {
    const data = await chrome.storage.local.get(["groqApiKey", "groqModel"]);
    if (data.groqApiKey) apiKeyInput.value = data.groqApiKey;
    if (data.groqModel && modelSelect) modelSelect.value = data.groqModel;
  }

  async function saveConfig() {
    const apiKey = apiKeyInput.value.trim();
    const model = modelSelect ? modelSelect.value : "openai/gpt-oss-20b";

    await chrome.storage.local.set({
      groqApiKey: apiKey,
      groqModel: model
    });

    if (settingsFeedback) {
      settingsFeedback.innerText = "Settings saved successfully!";
      settingsFeedback.style.color = "#10b981";
      setTimeout(() => {
        settingsFeedback.innerText = "";
        settingsSection.classList.add("hidden");
      }, 1200);
    }
  }

  async function refreshModels() {
    const apiKey = apiKeyInput.value.trim();
    if (!apiKey) {
      alert("Please enter a Groq API key first.");
      return;
    }

    if (btnFetchModels) {
      btnFetchModels.innerText = "Fetching...";
      btnFetchModels.disabled = true;
    }

    try {
      const res = await fetch("https://api.groq.com/openai/v1/models", {
        headers: { "Authorization": `Bearer ${apiKey}` }
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      const models = (data.data || [])
        .map(m => m.id)
        .filter(id => !id.includes("whisper") && !id.includes("vision") && !id.includes("guard"))
        .sort();

      if (models.length > 0 && modelSelect) {
        modelSelect.innerHTML = "";
        models.forEach(id => {
          const opt = document.createElement("option");
          opt.value = id;
          opt.innerText = id;
          modelSelect.appendChild(opt);
        });
        await chrome.storage.local.set({ groqModel: modelSelect.value });
      }
    } catch (err) {
      alert(`Could not fetch models: ${err.message}`);
    } finally {
      if (btnFetchModels) {
        btnFetchModels.innerText = "Refresh Models";
        btnFetchModels.disabled = false;
      }
    }
  }

  // ----------------------------------------------------
  // Problem Inspection from Active Scaler Tab
  // ----------------------------------------------------
  async function getActiveScalerTab() {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tabs[0] && tabs[0].url && tabs[0].url.includes("scaler.com")) {
      return tabs[0];
    }
    const allScalerTabs = await chrome.tabs.query({ url: "*://*.scaler.com/*" });
    return allScalerTabs.length > 0 ? allScalerTabs[0] : null;
  }

  async function syncProblemContext() {
    const tab = await getActiveScalerTab();
    if (!tab) {
      if (ribbonTitle) ribbonTitle.innerText = "Open a Scaler problem tab";
      return null;
    }

    try {
      let res;
      try {
        res = await chrome.tabs.sendMessage(tab.id, { action: "GET_QUESTION" });
      } catch (_) {
        // Inject read-only scripts if needed
        await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          files: ["content/extractor.js", "content/content.js"]
        });
        res = await chrome.tabs.sendMessage(tab.id, { action: "GET_QUESTION" });
      }

      if (res && res.success && res.data) {
        currentQuestion = res.data;

        if (ribbonQ) ribbonQ.innerText = currentQuestion.currentQNumber || "Q";
        if (ribbonTitle) ribbonTitle.innerText = currentQuestion.title || "Assignment Problem";
        const heroSubtext = document.querySelector(".hero-subtext");
        if (heroSubtext) {
          heroSubtext.innerText = `SST Assist is synced with ${currentQuestion.currentQNumber || "Q"} • ${currentQuestion.title || "Problem"}`;
        }
        return currentQuestion;
      }
    } catch (err) {
      console.warn("[SST Assist] Sync error:", err);
    }
    return null;
  }

  // ----------------------------------------------------
  // Event Listeners & Chat Flow
  // ----------------------------------------------------
  document.addEventListener("DOMContentLoaded", async () => {
    await loadConfig();

    // Hotkey listener inside sidepanel: Alt+A or Escape to smoothly close
    window.addEventListener("keydown", (e) => {
      if (e.altKey && (e.key === "a" || e.key === "A" || e.code === "KeyA")) {
        e.preventDefault();
        triggerSmoothClose();
      } else if (e.key === "Escape") {
        e.preventDefault();
        triggerSmoothClose();
      }
    });

    handleSummonFocus();

    // Settings Toggle
    if (btnSettingsToggle && settingsSection) {
      btnSettingsToggle.addEventListener("click", () => {
        settingsSection.classList.toggle("hidden");
      });
    }
    if (btnCloseSettings && settingsSection) {
      btnCloseSettings.addEventListener("click", () => {
        settingsSection.classList.add("hidden");
      });
    }
    if (btnSaveSettings) {
      btnSaveSettings.addEventListener("click", saveConfig);
    }
    if (btnFetchModels) {
      btnFetchModels.addEventListener("click", refreshModels);
    }

    // Manual Re-sync Problem Context
    if (btnSyncProblem) {
      btnSyncProblem.addEventListener("click", async () => {
        btnSyncProblem.classList.add("spinning");
        await syncProblemContext();
        setTimeout(() => btnSyncProblem.classList.remove("spinning"), 600);
      });
    }

    // Send Message Handler
    const handleSend = async (customText = null, isBailout = false) => {
      const text = customText || chatInput?.value?.trim();
      if (!text) return;

      if (!customText && chatInput) {
        chatInput.value = "";
        chatInput.style.height = "auto";
      }

      const { groqApiKey, groqModel } = await chrome.storage.local.get(["groqApiKey", "groqModel"]);
      if (!groqApiKey) {
        settingsSection?.classList.remove("hidden");
        alert("Please enter and save your Groq API key in the settings drawer above.");
        return;
      }

      await window.SST_Tutor.sendAssistantMessage({
        userText: text,
        questionData: currentQuestion,
        chatHistory: chatHistory,
        chatStreamEl: chatStream,
        apiKey: groqApiKey,
        model: groqModel || "openai/gpt-oss-20b",
        isSolutionBailout: isBailout
      });
    };

    if (btnSend && chatInput) {
      btnSend.addEventListener("click", () => handleSend());
      chatInput.addEventListener("keydown", (e) => {
        if (e.key === "Enter" && !e.shiftKey) {
          e.preventDefault();
          handleSend();
        }
      });
      chatInput.addEventListener("input", () => {
        chatInput.style.height = "auto";
        chatInput.style.height = Math.min(chatInput.scrollHeight, 120) + "px";
      });
    }

    // 3-Tier Progressive Scaffolding Pills
    ladderPills.forEach(pill => {
      pill.addEventListener("click", () => {
        const prompt = pill.dataset.prompt;
        if (prompt) handleSend(prompt, false);
      });
    });

    // Gemini Hero Suggestion Cards
    function attachSuggestionListeners() {
      document.querySelectorAll(".suggestion-card").forEach(card => {
        card.addEventListener("click", () => {
          const prompt = card.dataset.prompt;
          if (prompt) handleSend(prompt, false);
        });
      });
    }
    attachSuggestionListeners();

    // Emergency Bailout Walkthrough Button
    if (btnBailout) {
      btnBailout.addEventListener("click", () => {
        const confirmed = confirm(
          "Unlock full pedagogical solution walkthrough?\n\nAs your AI Tutor, I recommend attempting the 3 progressive Hint Ladder steps first.\n\nIf you are truly stuck, click OK to receive a complete solution with clean annotated code, explanation of logic, and Time/Space complexity."
        );
        if (!confirmed) return;

        handleSend(
          "I am completely stuck and have struggled with this problem. Please provide the full optimal solution with clean annotated code, explanation of logic, and detailed Time/Space complexity.",
          true
        );
      });
    }

    // Clear Chat -> Reset to Gemini Empty State Hero
    if (btnClear && chatStream) {
      btnClear.addEventListener("click", () => {
        chatHistory = [];
        chatStream.innerHTML = `
          <div class="gemini-hero" id="geminiHero">
            <div class="hero-spark-wrap">
              <svg class="hero-spark" viewBox="0 0 24 24" fill="none">
                <path d="M12 2C12 7.5 16.5 12 22 12C16.5 12 12 16.5 12 22C12 16.5 7.5 12 2 12C7.5 12 12 7.5 12 2Z" fill="url(#heroSparkGrad)"/>
                <defs>
                  <linearGradient id="heroSparkGrad" x1="2" y1="2" x2="22" y2="22" gradientUnits="userSpaceOnUse">
                    <stop offset="0%" stop-color="#38bdf8"/>
                    <stop offset="50%" stop-color="#818cf8"/>
                    <stop offset="100%" stop-color="#c084fc"/>
                  </linearGradient>
                </defs>
              </svg>
            </div>
            <h1 class="hero-heading">Where should we start?</h1>
            <p class="hero-subtext">SST Assist is synced with your problem</p>
            <div class="hero-suggestions">
              <button class="suggestion-card" data-prompt="Explain the core intuition and mental model for this problem without giving away code.">
                <span class="suggestion-title">Explain the core concept</span>
                <span class="suggestion-desc">Build a mental model of how to approach it</span>
              </button>
              <button class="suggestion-card" data-prompt="Can you walk me through the step-by-step algorithm flow or pseudocode?">
                <span class="suggestion-title">Outline the logic blueprint</span>
                <span class="suggestion-desc">High-level steps before writing syntax</span>
              </button>
              <button class="suggestion-card" data-prompt="What critical edge cases or tricky test inputs should I look out for?">
                <span class="suggestion-title">Uncover hidden edge cases</span>
                <span class="suggestion-desc">Avoid off-by-one errors and corner cases</span>
              </button>
            </div>
          </div>
        `;
        attachSuggestionListeners();
        const heroSub = document.querySelector(".hero-subtext");
        if (heroSub && currentQuestion) {
          heroSub.innerText = `SST Assist is synced with ${currentQuestion.currentQNumber || "Q"} • ${currentQuestion.title || "Problem"}`;
        }
      });
    }

    // Initial problem sync
    await syncProblemContext();
  });

  // Tab activation & update listeners
  chrome.tabs.onActivated.addListener(async (activeInfo) => {
    try {
      const tab = await chrome.tabs.get(activeInfo.tabId);
      if (tab?.url?.includes("scaler.com")) {
        syncProblemContext();
      }
    } catch (_) {}
  });

  chrome.tabs.onUpdated.addListener(async (tabId, changeInfo) => {
    if (changeInfo.url?.includes("scaler.com")) {
      syncProblemContext();
    }
  });

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg && msg.action === "PAGE_QUESTION_CHANGED") {
      syncProblemContext();
    }
  });
})();
